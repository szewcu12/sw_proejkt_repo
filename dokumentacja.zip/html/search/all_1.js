var searchData=
[
  ['configcpu_5fclock_5fhz_0',['configCPU_CLOCK_HZ',['../_free_r_t_o_s_config_8h.html#aa68082df879e6fc96bcb9b26513639e7',1,'FreeRTOSConfig.h']]],
  ['configidle_5fshould_5fyield_1',['configIDLE_SHOULD_YIELD',['../_free_r_t_o_s_config_8h.html#ad6a5061a742fee450ac455e4ad0f4b6c',1,'FreeRTOSConfig.h']]],
  ['configmax_5fco_5froutine_5fpriorities_2',['configMAX_CO_ROUTINE_PRIORITIES',['../_free_r_t_o_s_config_8h.html#ae8f3fd645e6e78dfeb8a6e874af6195a',1,'FreeRTOSConfig.h']]],
  ['configmax_5fpriorities_3',['configMAX_PRIORITIES',['../_free_r_t_o_s_config_8h.html#a9a78f5ac61e6cb172dadf2a51f11db38',1,'FreeRTOSConfig.h']]],
  ['configmax_5ftask_5fname_5flen_4',['configMAX_TASK_NAME_LEN',['../_free_r_t_o_s_config_8h.html#ac388dc4041aab6997348828eb27fc1a8',1,'FreeRTOSConfig.h']]],
  ['configminimal_5fstack_5fsize_5',['configMINIMAL_STACK_SIZE',['../_free_r_t_o_s_config_8h.html#a6c534a6cf8a00528fe0be42083484f9a',1,'FreeRTOSConfig.h']]],
  ['configqueue_5fregistry_5fsize_6',['configQUEUE_REGISTRY_SIZE',['../_free_r_t_o_s_config_8h.html#aa4b5138c4e42a180f0abd4f2455f90fb',1,'FreeRTOSConfig.h']]],
  ['configtick_5frate_5fhz_7',['configTICK_RATE_HZ',['../_free_r_t_o_s_config_8h.html#a2f0258dd1e3b877e5bc013be54c2db6a',1,'FreeRTOSConfig.h']]],
  ['configtotal_5fheap_5fsize_8',['configTOTAL_HEAP_SIZE',['../_free_r_t_o_s_config_8h.html#a9f213227674effff0122a75d94d87938',1,'FreeRTOSConfig.h']]],
  ['configuse_5f16_5fbit_5fticks_9',['configUSE_16_BIT_TICKS',['../_free_r_t_o_s_config_8h.html#aac311ed9b9e5ae4d2d9648b33a24acce',1,'FreeRTOSConfig.h']]],
  ['configuse_5fco_5froutines_10',['configUSE_CO_ROUTINES',['../_free_r_t_o_s_config_8h.html#a57990715eb06402474b8b47e1d562616',1,'FreeRTOSConfig.h']]],
  ['configuse_5fidle_5fhook_11',['configUSE_IDLE_HOOK',['../_free_r_t_o_s_config_8h.html#ac637ae45863c19fa2e919db0ed49301f',1,'FreeRTOSConfig.h']]],
  ['configuse_5fpreemption_12',['configUSE_PREEMPTION',['../_free_r_t_o_s_config_8h.html#adde83486022745409c40605922b0bdd6',1,'FreeRTOSConfig.h']]],
  ['configuse_5ftick_5fhook_13',['configUSE_TICK_HOOK',['../_free_r_t_o_s_config_8h.html#a23c5922c077106fad3f70b54d9071466',1,'FreeRTOSConfig.h']]],
  ['configuse_5ftrace_5ffacility_14',['configUSE_TRACE_FACILITY',['../_free_r_t_o_s_config_8h.html#a27f5ee137dc9f125681a31f0b0a4b3be',1,'FreeRTOSConfig.h']]]
];
