var searchData=
[
  ['led_5fbuf_0',['LED_buf',['../main_8c.html#a41f6e8e937b06459b83eb165b37866e2',1,'main.c']]],
  ['led_5fptr_1',['LED_ptr',['../main_8c.html#aea357b2244a322340ebc33e274afa15c',1,'main.c']]]
];
