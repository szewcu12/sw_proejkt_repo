var searchData=
[
  ['autorzy_3a_20maciej_20szewczyk_2c_20krzysztof_20tomański_0',['Autorzy: Maciej Szewczyk, Krzysztof Tomański',['../index.html',1,'']]]
];
