var searchData=
[
  ['ds18b20_5ftask_5fpriority_0',['DS18B20_TASK_PRIORITY',['../main_8c.html#ad5a64b4959794aefcb451276fa2dbc1a',1,'main.c']]]
];
