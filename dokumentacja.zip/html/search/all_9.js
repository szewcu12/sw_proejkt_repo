var searchData=
[
  ['progmem_0',['PROGMEM',['../main_8c.html#ad874737a9a6e06b5834171da85ab7784',1,'main.c']]],
  ['prvdisplaytemp_1',['prvDisplayTemp',['../main_8c.html#a18802e83a12cf8e2690f9187a9bdc9d9',1,'main.c']]],
  ['prvinithardware_2',['prvInitHardware',['../main_8c.html#a97406766e6069baf97bd4ad8a6385f05',1,'main.c']]]
];
