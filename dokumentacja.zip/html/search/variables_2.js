var searchData=
[
  ['mode_0',['mode',['../main_8c.html#a37e90f5e3bd99fac2021fb3a326607d4',1,'main.c']]]
];
