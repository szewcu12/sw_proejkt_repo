var searchData=
[
  ['prvdisplaytemp_0',['prvDisplayTemp',['../main_8c.html#a18802e83a12cf8e2690f9187a9bdc9d9',1,'main.c']]],
  ['prvinithardware_1',['prvInitHardware',['../main_8c.html#a97406766e6069baf97bd4ad8a6385f05',1,'main.c']]]
];
