var searchData=
[
  ['vtaskkeysled_0',['vTaskKeysLed',['../main_8c.html#ad99774cb80b278756072f5fe30fd5891',1,'main.c']]],
  ['vtaskmeastemp_1',['vTaskMeasTemp',['../main_8c.html#aef6cc9473c6482cd643bd1fd63a98a09',1,'main.c']]]
];
