var searchData=
[
  ['number_5fof_5fdigits_0',['NUMBER_OF_DIGITS',['../main_8c.html#a56d4445bb325117c85912f69b84d6b7d',1,'main.c']]]
];
